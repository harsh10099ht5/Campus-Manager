<?php 
include('../config/db.php');

$students = $conn->query("SELECT * FROM students");
$subjects = $conn->query("SELECT * FROM subjects");

if($_POST){
  $q=$conn->prepare("INSERT INTO marks(student_id,subject,marks) VALUES(?,?,?)");
  $q->bind_param("iii", $_POST['student'], $_POST['subject'], $_POST['marks']);
  $q->execute();

  echo "<script>alert('Marks Added');</script>";
}
?>

<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

<div class="ml-64 p-6 bg-gray-100 min-h-screen">

<h2 class="text-xl mb-4">Add Marks</h2>

<form method="POST" class="bg-white p-6 rounded-xl shadow w-96">

<select name="student" class="border p-2 w-full mb-3" required>
<option value="">Select Student</option>
<?php while($s=$students->fetch_assoc()): ?>
<option value="<?= $s['id'] ?>"><?= $s['name'] ?> (<?= $s['class'] ?>)</option>
<?php endwhile; ?>
</select>

<select name="subject" class="border p-2 w-full mb-3" required>
<option value="">Select Subject</option>
<?php while($sub=$subjects->fetch_assoc()): ?>
<option value="<?= $sub['id'] ?>"><?= $sub['name'] ?></option>
<?php endwhile; ?>
</select>

<input type="number" name="marks" placeholder="Marks (0–100)"
class="border p-2 w-full mb-3" min="0" max="100" required>

<button class="bg-blue-600 text-white px-4 py-2 rounded w-full">
Save Marks
</button>

</form>

</div>